var gdjs;(function(f){f.gdevelopLogo="data:image/png,"})(gdjs||(gdjs={}));
//# sourceMappingURL=gd-logo-dark-colored.js.map
