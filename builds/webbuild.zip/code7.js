gdjs.Level3Code = {};
gdjs.Level3Code.GDplayerObjects1= [];
gdjs.Level3Code.GDplayerObjects2= [];
gdjs.Level3Code.GDplayerObjects3= [];
gdjs.Level3Code.GDspikeObjects1= [];
gdjs.Level3Code.GDspikeObjects2= [];
gdjs.Level3Code.GDspikeObjects3= [];
gdjs.Level3Code.GDportalObjects1= [];
gdjs.Level3Code.GDportalObjects2= [];
gdjs.Level3Code.GDportalObjects3= [];
gdjs.Level3Code.GDfloorObjects1= [];
gdjs.Level3Code.GDfloorObjects2= [];
gdjs.Level3Code.GDfloorObjects3= [];


gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDfloorObjects1Objects = Hashtable.newFrom({"floor": gdjs.Level3Code.GDfloorObjects1});
gdjs.Level3Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level3Code.GDplayerObjects1, gdjs.Level3Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.Level3Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDplayerObjects2[i].addForce(0, 15000 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level3Code.GDplayerObjects1, gdjs.Level3Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.Level3Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDplayerObjects2[i].addForce(-(15000) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level3Code.GDplayerObjects1, gdjs.Level3Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.Level3Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Level3Code.GDplayerObjects2[i].addForce(15000 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
/* Reuse gdjs.Level3Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs.Level3Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayerObjects1[i].addForce(0, -(15000) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), 0);
}
}}

}


};gdjs.Level3Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


};gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.Level3Code.GDplayerObjects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.Level3Code.GDspikeObjects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.Level3Code.GDplayerObjects1});
gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDportalObjects1Objects = Hashtable.newFrom({"portal": gdjs.Level3Code.GDportalObjects1});
gdjs.Level3Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Level3Code.GDplayerObjects1);
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "cameratoplayer", (( gdjs.Level3Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDplayerObjects1[0].getPointX("")), (( gdjs.Level3Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Level3Code.GDplayerObjects1[0].getPointY("")), "", 5, "in");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("floor"), gdjs.Level3Code.GDfloorObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Level3Code.GDplayerObjects1);
{for(var i = 0, len = gdjs.Level3Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Level3Code.GDplayerObjects1[i].separateFromObjectsList(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDfloorObjects1Objects, false);
}
}
{ //Subevents
gdjs.Level3Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{ //Subevents
gdjs.Level3Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Level3Code.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.Level3Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayerObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDspikeObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Level3Code.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("portal"), gdjs.Level3Code.GDportalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDplayerObjects1Objects, gdjs.Level3Code.mapOfGDgdjs_46Level3Code_46GDportalObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), false);
}}

}


};

gdjs.Level3Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level3Code.GDplayerObjects1.length = 0;
gdjs.Level3Code.GDplayerObjects2.length = 0;
gdjs.Level3Code.GDplayerObjects3.length = 0;
gdjs.Level3Code.GDspikeObjects1.length = 0;
gdjs.Level3Code.GDspikeObjects2.length = 0;
gdjs.Level3Code.GDspikeObjects3.length = 0;
gdjs.Level3Code.GDportalObjects1.length = 0;
gdjs.Level3Code.GDportalObjects2.length = 0;
gdjs.Level3Code.GDportalObjects3.length = 0;
gdjs.Level3Code.GDfloorObjects1.length = 0;
gdjs.Level3Code.GDfloorObjects2.length = 0;
gdjs.Level3Code.GDfloorObjects3.length = 0;

gdjs.Level3Code.eventsList2(runtimeScene);

return;

}

gdjs['Level3Code'] = gdjs.Level3Code;
