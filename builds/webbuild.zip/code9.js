gdjs.Level1Code = {};
gdjs.Level1Code.GDplayerObjects1= [];
gdjs.Level1Code.GDplayerObjects2= [];
gdjs.Level1Code.GDplayerObjects3= [];
gdjs.Level1Code.GDspikeObjects1= [];
gdjs.Level1Code.GDspikeObjects2= [];
gdjs.Level1Code.GDspikeObjects3= [];
gdjs.Level1Code.GDportalObjects1= [];
gdjs.Level1Code.GDportalObjects2= [];
gdjs.Level1Code.GDportalObjects3= [];
gdjs.Level1Code.GDfloorObjects1= [];
gdjs.Level1Code.GDfloorObjects2= [];
gdjs.Level1Code.GDfloorObjects3= [];


gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDfloorObjects1Objects = Hashtable.newFrom({"floor": gdjs.Level1Code.GDfloorObjects1});
gdjs.Level1Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDplayerObjects1, gdjs.Level1Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.Level1Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDplayerObjects2[i].addForce(0, 15000 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 1;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDplayerObjects1, gdjs.Level1Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.Level1Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDplayerObjects2[i].addForce(-(15000) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 2;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level1Code.GDplayerObjects1, gdjs.Level1Code.GDplayerObjects2);

{for(var i = 0, len = gdjs.Level1Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs.Level1Code.GDplayerObjects2[i].addForce(15000 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), 0, 0);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 3;
if (isConditionTrue_0) {
/* Reuse gdjs.Level1Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs.Level1Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDplayerObjects1[i].addForce(0, -(15000) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene), 0);
}
}}

}


};gdjs.Level1Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) == 4;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}}

}


};gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.Level1Code.GDplayerObjects1});
gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDspikeObjects1Objects = Hashtable.newFrom({"spike": gdjs.Level1Code.GDspikeObjects1});
gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs.Level1Code.GDplayerObjects1});
gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDportalObjects1Objects = Hashtable.newFrom({"portal": gdjs.Level1Code.GDportalObjects1});
gdjs.Level1Code.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Level1Code.GDplayerObjects1);
{gdjs.evtTools.tween.tweenCamera(runtimeScene, "cameratoplayer", (( gdjs.Level1Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDplayerObjects1[0].getPointX("")), (( gdjs.Level1Code.GDplayerObjects1.length === 0 ) ? 0 :gdjs.Level1Code.GDplayerObjects1[0].getPointY("")), "", 5, "in");
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("floor"), gdjs.Level1Code.GDfloorObjects1);
gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Level1Code.GDplayerObjects1);
{for(var i = 0, len = gdjs.Level1Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs.Level1Code.GDplayerObjects1[i].separateFromObjectsList(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDfloorObjects1Objects, false);
}
}
{ //Subevents
gdjs.Level1Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{ //Subevents
gdjs.Level1Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Level1Code.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("spike"), gdjs.Level1Code.GDspikeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDplayerObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDspikeObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("player"), gdjs.Level1Code.GDplayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("portal"), gdjs.Level1Code.GDportalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDplayerObjects1Objects, gdjs.Level1Code.mapOfGDgdjs_46Level1Code_46GDportalObjects1Objects, false, runtimeScene, true);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))), false);
}}

}


};

gdjs.Level1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1Code.GDplayerObjects1.length = 0;
gdjs.Level1Code.GDplayerObjects2.length = 0;
gdjs.Level1Code.GDplayerObjects3.length = 0;
gdjs.Level1Code.GDspikeObjects1.length = 0;
gdjs.Level1Code.GDspikeObjects2.length = 0;
gdjs.Level1Code.GDspikeObjects3.length = 0;
gdjs.Level1Code.GDportalObjects1.length = 0;
gdjs.Level1Code.GDportalObjects2.length = 0;
gdjs.Level1Code.GDportalObjects3.length = 0;
gdjs.Level1Code.GDfloorObjects1.length = 0;
gdjs.Level1Code.GDfloorObjects2.length = 0;
gdjs.Level1Code.GDfloorObjects3.length = 0;

gdjs.Level1Code.eventsList2(runtimeScene);

return;

}

gdjs['Level1Code'] = gdjs.Level1Code;
