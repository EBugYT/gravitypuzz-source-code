gdjs.Level10Code = {};
gdjs.Level10Code.GDplayerObjects1= [];
gdjs.Level10Code.GDplayerObjects2= [];
gdjs.Level10Code.GDspikeObjects1= [];
gdjs.Level10Code.GDspikeObjects2= [];
gdjs.Level10Code.GDportalObjects1= [];
gdjs.Level10Code.GDportalObjects2= [];
gdjs.Level10Code.GDfloorObjects1= [];
gdjs.Level10Code.GDfloorObjects2= [];
gdjs.Level10Code.GDNewTextObjects1= [];
gdjs.Level10Code.GDNewTextObjects2= [];
gdjs.Level10Code.GDNewText2Objects1= [];
gdjs.Level10Code.GDNewText2Objects2= [];
gdjs.Level10Code.GDGdevelopObjects1= [];
gdjs.Level10Code.GDGdevelopObjects2= [];


gdjs.Level10Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Level10Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level10Code.GDplayerObjects1.length = 0;
gdjs.Level10Code.GDplayerObjects2.length = 0;
gdjs.Level10Code.GDspikeObjects1.length = 0;
gdjs.Level10Code.GDspikeObjects2.length = 0;
gdjs.Level10Code.GDportalObjects1.length = 0;
gdjs.Level10Code.GDportalObjects2.length = 0;
gdjs.Level10Code.GDfloorObjects1.length = 0;
gdjs.Level10Code.GDfloorObjects2.length = 0;
gdjs.Level10Code.GDNewTextObjects1.length = 0;
gdjs.Level10Code.GDNewTextObjects2.length = 0;
gdjs.Level10Code.GDNewText2Objects1.length = 0;
gdjs.Level10Code.GDNewText2Objects2.length = 0;
gdjs.Level10Code.GDGdevelopObjects1.length = 0;
gdjs.Level10Code.GDGdevelopObjects2.length = 0;

gdjs.Level10Code.eventsList0(runtimeScene);

return;

}

gdjs['Level10Code'] = gdjs.Level10Code;
