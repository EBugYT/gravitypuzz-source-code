gdjs.Main_32ScreenCode = {};
gdjs.Main_32ScreenCode.GDNewTextObjects1= [];
gdjs.Main_32ScreenCode.GDNewTextObjects2= [];
gdjs.Main_32ScreenCode.GDNewText2Objects1= [];
gdjs.Main_32ScreenCode.GDNewText2Objects2= [];


gdjs.Main_32ScreenCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


};

gdjs.Main_32ScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32ScreenCode.GDNewTextObjects1.length = 0;
gdjs.Main_32ScreenCode.GDNewTextObjects2.length = 0;
gdjs.Main_32ScreenCode.GDNewText2Objects1.length = 0;
gdjs.Main_32ScreenCode.GDNewText2Objects2.length = 0;

gdjs.Main_32ScreenCode.eventsList0(runtimeScene);

return;

}

gdjs['Main_32ScreenCode'] = gdjs.Main_32ScreenCode;
